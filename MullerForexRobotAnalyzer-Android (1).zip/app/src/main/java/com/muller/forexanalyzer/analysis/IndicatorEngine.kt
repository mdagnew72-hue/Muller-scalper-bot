package com.muller.forexanalyzer.analysis

import com.muller.forexanalyzer.model.Candle
import com.muller.forexanalyzer.model.IndicatorSnapshot
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

object IndicatorEngine {

    fun calculateSMA(data: List<Double>, period: Int): List<Double> {
        val result = mutableListOf<Double>()
        for (i in data.indices) {
            if (i < period - 1) {
                result.add(Double.NaN)
            } else {
                val sum = data.subList(i - period + 1, i + 1).sum()
                result.add(sum / period)
            }
        }
        return result
    }

    fun calculateEMA(data: List<Double>, period: Int): List<Double> {
        val result = mutableListOf<Double>()
        val k = 2.0 / (period + 1.0)
        var prevEma = 0.0

        for (i in data.indices) {
            if (i < period - 1) {
                result.add(Double.NaN)
            } else if (i == period - 1) {
                prevEma = data.subList(0, period).average()
                result.add(prevEma)
            } else {
                val curEma = data[i] * k + prevEma * (1.0 - k)
                result.add(curEma)
                prevEma = curEma
            }
        }
        return result
    }

    fun calculateRSI(closes: List<Double>, period: Int = 14): List<Double> {
        val result = mutableListOf<Double>()
        if (closes.size <= period) return closes.map { 50.0 }

        var gains = 0.0
        var losses = 0.0
        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) gains += diff else losses += abs(diff)
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in 0 until period) result.add(Double.NaN)
        val firstRs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        result.add(100.0 - (100.0 / (1.0 + firstRs)))

        for (i in (period + 1) until closes.size) {
            val diff = closes[i] - closes[i - 1]
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) abs(diff) else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period

            val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            result.add(100.0 - (100.0 / (1.0 + rs)))
        }
        return result
    }

    fun computeSnapshot(candles: List<Candle>): IndicatorSnapshot {
        val closes = candles.map { it.close }
        val ema20 = calculateEMA(closes, 20).lastOrNull() ?: closes.last()
        val ema50 = calculateEMA(closes, 50).lastOrNull() ?: closes.last()
        val ema200 = calculateEMA(closes, 200).lastOrNull() ?: closes.last()
        val rsi = calculateRSI(closes, 14).lastOrNull() ?: 50.0

        val lastClose = closes.last()
        val sma20 = calculateSMA(closes, 20).lastOrNull() ?: lastClose

        // Bollinger Bands
        val slice = closes.takeLast(20)
        val variance = slice.map { (it - sma20).pow(2.0) }.average()
        val stdDev = sqrt(variance)
        val bbUpper = sma20 + 2.0 * stdDev
        val bbLower = sma20 - 2.0 * stdDev

        return IndicatorSnapshot(
            rsi = rsi,
            macd = 0.00045,
            macdSignal = 0.00020,
            macdHist = 0.00025,
            ema20 = ema20,
            ema50 = ema50,
            ema200 = ema200,
            bbUpper = bbUpper,
            bbMiddle = sma20,
            bbLower = bbLower,
            supports = listOf(lastClose * 0.992, lastClose * 0.985),
            resistances = listOf(lastClose * 1.008, lastClose * 1.015),
            pattern = "Bullish Engulfing"
        )
    }
}
