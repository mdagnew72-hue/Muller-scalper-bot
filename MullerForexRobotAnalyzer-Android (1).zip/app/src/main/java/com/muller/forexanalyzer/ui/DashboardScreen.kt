package com.muller.forexanalyzer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muller.forexanalyzer.model.AccountState
import com.muller.forexanalyzer.model.MarketSignal
import com.muller.forexanalyzer.model.SignalType
import com.muller.forexanalyzer.ui.theme.*

@Composable
fun DashboardScreen(
    accountState: AccountState,
    currentSignal: MarketSignal,
    onNavigateToChart: () -> Unit,
    onNavigateToMT5: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MULLER FOREX ROBOT",
                        color = GoldAccent,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "MT5 Multi-Timeframe Confluence Engine",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
                IconButton(onClick = onNavigateToMT5) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = "MT5 Import",
                        tint = GoldAccent
                    )
                }
            }
        }

        // Account Metrics Row
        item {
            AccountCardsRow(accountState)
        }

        // Active Session Badge
        item {
            SessionRadarBanner()
        }

        // Primary Confluence Signal Card
        item {
            SignalCardCompose(signal = currentSignal, onViewChart = onNavigateToChart)
        }

        // Key Market Indicators Grid
        item {
            TechnicalStatusGrid(currentSignal)
        }
    }
}

@Composable
fun AccountCardsRow(accountState: AccountState) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Balance Card
        Column(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text("Balance", color = TextMuted, fontSize = 11.sp)
            Text(
                "$${String.format("%.2f", accountState.balance)}",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text("MT5 Demo", color = TextMuted, fontSize = 10.sp)
        }

        // Equity Card
        Column(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text("Equity (Floating)", color = TextMuted, fontSize = 11.sp)
            Text(
                "$${String.format("%.2f", accountState.equity)}",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "+$${String.format("%.2f", accountState.floatingPnL)} (+4.8%)",
                color = GreenAccent,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun SessionRadarBanner() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Public, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(16.dp))
            Text("London + New York Session", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("High Volatility", color = GoldAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SignalCardCompose(signal: MarketSignal, onViewChart: () -> Unit) {
    val isBuy = signal.action == SignalType.BUY
    val isSell = signal.action == SignalType.SELL
    val accentColor = if (isBuy) GreenAccent else if (isSell) RedAccent else GoldAccent

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardSurface)
            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(signal.symbol, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text(
                    "${signal.timeframe} · ${signal.candlePattern}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
            Surface(
                color = accentColor,
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${signal.action} SIGNAL",
                    color = Color.Black,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Strength Bar
        Text("Confluence Strength: ${signal.strength}%", color = accentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(
            progress = signal.strength / 100f,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = accentColor,
            trackColor = Color(0xFF1E293B)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Targets row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF07090E))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ENTRY", color = TextMuted, fontSize = 9.sp)
                Text(String.format("%.5f", signal.entryPrice), color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("STOP LOSS", color = RedAccent, fontSize = 9.sp)
                Text(String.format("%.5f", signal.stopLoss), color = RedAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TAKE PROFIT", color = GreenAccent, fontSize = 9.sp)
                Text(String.format("%.5f", signal.takeProfit1), color = GreenAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("R:R", color = GoldAccent, fontSize = 9.sp)
                Text(signal.riskReward, color = GoldAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Reasons
        Text("Signal Rationale:", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        signal.reasons.forEach { reason ->
            Text("• $reason", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 1.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onViewChart,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
        ) {
            Text("Open Interactive Chart", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TechnicalStatusGrid(signal: MarketSignal) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text("Engine Confluence Status", color = GoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("RSI(14): 42.4 (Recovering)", color = TextMuted, fontSize = 11.sp)
            Text("EMA Stack: Bullish 20>50", color = GreenAccent, fontSize = 11.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Bollinger Bands: Lower Band Test", color = BlueAccent, fontSize = 11.sp)
            Text("MACD: Positive Histogram", color = GreenAccent, fontSize = 11.sp)
        }
    }
}
