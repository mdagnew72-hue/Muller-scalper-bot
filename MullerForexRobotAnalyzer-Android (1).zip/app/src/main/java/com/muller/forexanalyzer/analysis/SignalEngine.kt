package com.muller.forexanalyzer.analysis

import com.muller.forexanalyzer.model.Candle
import com.muller.forexanalyzer.model.MarketSignal
import com.muller.forexanalyzer.model.SignalType

object SignalEngine {

    fun generateSignal(symbol: String, timeframe: String, candles: List<Candle>): MarketSignal {
        if (candles.size < 30) {
            val price = candles.lastOrNull()?.close ?: 1.08500
            return MarketSignal(
                id = "sig_${System.currentTimeMillis()}",
                symbol = symbol,
                timeframe = timeframe,
                action = SignalType.WAIT,
                strength = 45,
                entryPrice = price,
                stopLoss = price * 0.995,
                takeProfit1 = price * 1.008,
                takeProfit2 = price * 1.015,
                riskReward = "1:2.0",
                timestamp = System.currentTimeMillis(),
                candlePattern = "Insufficient Bars",
                reasons = listOf("Accumulating historical bar data from MT5")
            )
        }

        val snapshot = IndicatorEngine.computeSnapshot(candles)
        val currentPrice = candles.last().close
        val reasons = mutableListOf<String>()
        var buyPoints = 0
        var sellPoints = 0

        // 1. Moving average alignment
        if (currentPrice > snapshot.ema20 && snapshot.ema20 > snapshot.ema50) {
            buyPoints += 30
            reasons.add("Price above EMA(20) with EMA(20) > EMA(50) bullish alignment")
        } else if (currentPrice < snapshot.ema20 && snapshot.ema20 < snapshot.ema50) {
            sellPoints += 30
            reasons.add("Price rejected below EMA(20) with EMA(20) < EMA(50) bearish trend")
        }

        // 2. RSI momentum
        if (snapshot.rsi < 35.0) {
            buyPoints += 25
            reasons.add("RSI(14) oversold at ${String.format("%.1f", snapshot.rsi)} pointing upward")
        } else if (snapshot.rsi > 65.0) {
            sellPoints += 25
            reasons.add("RSI(14) overbought at ${String.format("%.1f", snapshot.rsi)} showing seller resistance")
        } else if (snapshot.rsi > 50.0) {
            buyPoints += 15
            reasons.add("RSI(14) in bullish expansion zone (${String.format("%.1f", snapshot.rsi)})")
        }

        // 3. Bollinger Bands & Reversal
        if (currentPrice <= snapshot.bbLower * 1.002) {
            buyPoints += 20
            reasons.add("Price testing lower Bollinger Band with high probability mean reversion")
        } else if (currentPrice >= snapshot.bbUpper * 0.998) {
            sellPoints += 20
            reasons.add("Price testing upper Bollinger Band extreme resistance")
        }

        // Decide signal
        val action: SignalType
        val strength: Int
        val sl: Double
        val tp1: Double
        val tp2: Double

        val slDistance = currentPrice * 0.0025

        if (buyPoints >= 50 && buyPoints > sellPoints + 15) {
            action = SignalType.BUY
            strength = minOf(95, (buyPoints * 1.1).toInt())
            sl = currentPrice - slDistance
            tp1 = currentPrice + slDistance * 1.5
            tp2 = currentPrice + slDistance * 2.8
        } else if (sellPoints >= 50 && sellPoints > buyPoints + 15) {
            action = SignalType.SELL
            strength = minOf(95, (sellPoints * 1.1).toInt())
            sl = currentPrice + slDistance
            tp1 = currentPrice - slDistance * 1.5
            tp2 = currentPrice - slDistance * 2.8
        } else {
            action = SignalType.WAIT
            strength = maxOf(buyPoints, sellPoints)
            sl = currentPrice - slDistance
            tp1 = currentPrice + slDistance * 1.5
            tp2 = currentPrice + slDistance * 2.5
            reasons.add("Market consolidating in neutral range; waiting for high-volume breakout")
        }

        return MarketSignal(
            id = "sig_${symbol}_${System.currentTimeMillis()}",
            symbol = symbol,
            timeframe = timeframe,
            action = action,
            strength = strength,
            entryPrice = currentPrice,
            stopLoss = sl,
            takeProfit1 = tp1,
            takeProfit2 = tp2,
            riskReward = "1:2.0",
            timestamp = System.currentTimeMillis(),
            candlePattern = snapshot.pattern ?: "Standard Candle",
            reasons = reasons
        )
    }
}
