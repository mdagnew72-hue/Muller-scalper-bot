package com.muller.forexanalyzer.parser

import com.muller.forexanalyzer.model.Candle
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

object MT5Parser {

    fun parse(inputStream: InputStream): List<Candle> {
        val reader = BufferedReader(InputStreamReader(inputStream))
        val candles = mutableListOf<Candle>()
        var line: String? = reader.readLine()
        var lineIndex = 0

        while (line != null) {
            val trimmed = line.trim()
            if (trimmed.isNotEmpty()) {
                val isHeader = trimmed.contains("date", ignoreCase = true) || trimmed.contains("<DATE>")
                if (!isHeader || lineIndex > 0) {
                    val delimiter = if (trimmed.contains("\t")) "\t" else if (trimmed.contains(",")) "," else ";"
                    val parts = trimmed.split(delimiter)
                    if (parts.size >= 5) {
                        try {
                            var dateStr = parts[0].trim()
                            var timeStr = "00:00:00"
                            var open = 0.0
                            var high = 0.0
                            var low = 0.0
                            var close = 0.0
                            var volume = 100L

                            if (parts.size >= 6 && parts[1].contains(":")) {
                                timeStr = parts[1].trim()
                                open = parts[2].toDouble()
                                high = parts[3].toDouble()
                                low = parts[4].toDouble()
                                close = parts[5].toDouble()
                                if (parts.size > 6) volume = parts[6].toDoubleOrNull()?.toLong() ?: 100L
                            } else {
                                open = parts[1].toDouble()
                                high = parts[2].toDouble()
                                low = parts[3].toDouble()
                                close = parts[4].toDouble()
                                if (parts.size > 5) volume = parts[5].toDoubleOrNull()?.toLong() ?: 100L
                            }

                            candles.add(
                                Candle(
                                    timestamp = System.currentTimeMillis() - (100 - lineIndex) * 3600000L,
                                    dateStr = dateStr,
                                    timeStr = timeStr,
                                    open = open,
                                    high = maxOf(high, open, close),
                                    low = minOf(low, open, close),
                                    close = close,
                                    volume = volume
                                )
                            )
                        } catch (_: Exception) {
                            // Skip malformed row
                        }
                    }
                }
            }
            line = reader.readLine()
            lineIndex++
        }
        return candles
    }
}
