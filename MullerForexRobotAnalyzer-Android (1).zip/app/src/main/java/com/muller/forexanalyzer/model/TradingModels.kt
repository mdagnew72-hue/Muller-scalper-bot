package com.muller.forexanalyzer.model

data class Candle(
    val timestamp: Long,
    val dateStr: String,
    val timeStr: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
)

enum class SignalType {
    BUY, SELL, WAIT
}

data class MarketSignal(
    val id: String,
    val symbol: String,
    val timeframe: String,
    val action: SignalType,
    val strength: Int,
    val entryPrice: Double,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val riskReward: String,
    val timestamp: Long,
    val candlePattern: String,
    val reasons: List<String>
)

data class IndicatorSnapshot(
    val rsi: Double,
    val macd: Double,
    val macdSignal: Double,
    val macdHist: Double,
    val ema20: Double,
    val ema50: Double,
    val ema200: Double,
    val bbUpper: Double,
    val bbMiddle: Double,
    val bbLower: Double,
    val supports: List<Double>,
    val resistances: List<Double>,
    val pattern: String?
)

data class AccountState(
    val balance: Double = 10000.00,
    val equity: Double = 10482.50,
    val margin: Double = 320.00,
    val freeMargin: Double = 10162.50,
    val marginLevel: Double = 3275.0,
    val floatingPnL: Double = 482.50,
    val winRate: Double = 73.4
)
