package com.muller.forexanalyzer.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF07090E)
val CardSurface = Color(0xFF0B0E17)
val CardBorder = Color(0xFF1E293B)
val GoldAccent = Color(0xFFE6B04C)
val BlueAccent = Color(0xFF00E5FF)
val GreenAccent = Color(0xFF10B981)
val RedAccent = Color(0xFFF43F5E)
val TextMuted = Color(0xFF94A3B8)
val TextPrimary = Color(0xFFF8FAFC)
