package com.muller.forexanalyzer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    secondary = BlueAccent,
    tertiary = GreenAccent,
    background = DarkBackground,
    surface = CardSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun MullerForexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
