package com.muller.forexanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.muller.forexanalyzer.analysis.SignalEngine
import com.muller.forexanalyzer.model.AccountState
import com.muller.forexanalyzer.model.Candle
import com.muller.forexanalyzer.ui.DashboardScreen
import com.muller.forexanalyzer.ui.theme.DarkBackground
import com.muller.forexanalyzer.ui.theme.MullerForexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MullerForexTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    val accountState = remember { AccountState() }
                    val dummyCandles = remember {
                        List(50) { i ->
                            Candle(
                                timestamp = System.currentTimeMillis() - i * 3600000L,
                                dateStr = "2026.11.01",
                                timeStr = "14:00:00",
                                open = 1.0840 + (i % 5) * 0.0004,
                                high = 1.0865 + (i % 5) * 0.0004,
                                low = 1.0820 + (i % 5) * 0.0004,
                                close = 1.0855 + (i % 5) * 0.0004,
                                volume = 1200L
                            )
                        }
                    }
                    val signal = remember {
                        SignalEngine.generateSignal("EURUSD", "H1", dummyCandles)
                    }

                    DashboardScreen(
                        accountState = accountState,
                        currentSignal = signal,
                        onNavigateToChart = { /* Open chart tab */ },
                        onNavigateToMT5 = { /* Open MT5 import tab */ }
                    )
                }
            }
        }
    }
}
